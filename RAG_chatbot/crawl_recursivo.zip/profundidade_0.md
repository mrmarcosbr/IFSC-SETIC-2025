# Páginas - Profundidade 0

## Cursos - Câmpus Joinville - Portal do IFSC

**URL:** https://www.ifsc.edu.br/web/campus-joinville/cursos

[](https://www.ifsc.edu.br/web/campus-joinville/cursos)[](https://www.ifsc.edu.br/web/campus-joinville/cursos)
  * [ Pular para o Conteúdo ](https://www.ifsc.edu.br/web/campus-joinville/cursos#main-content)


[Brasil](https://gov.br)
  * [](https://www.ifsc.edu.br/web/campus-joinville/cursos)
  * [Órgãos do Governo](https://www.gov.br/pt-br/orgaos-do-governo)
  * [Acesso à informação](https://www.gov.br/acessoainformacao/pt-br)
  * [Legislação](http://www4.planalto.gov.br/legislacao)

[](https://www.ifsc.edu.br/web/campus-joinville/cursos) ![](https://www.ifsc.edu.br/o/ifsc-internet-lf6_2-theme/images/vlibras.gif) O conteúdo desse portal pode ser acessível em Libras usando o [VLibras](http://www.vlibras.gov.br)
![Pin](https://www.ifsc.edu.br/o/ifsc-internet-lf6_2-theme/images/pin.svg)
#  [ ![Portal do IFSC](https://www.ifsc.edu.br/image/layout_set_logo?img_id=1274101&t=1749415502439) ](https://www.ifsc.edu.br/web/campus-joinville "Portal do IFSC") Câmpus Joinville 
##  Cursos - Câmpus Joinville
  * [ o câmpus](https://www.ifsc.edu.br/web/campus-joinville/o-campus)
  * [ cursos](https://www.ifsc.edu.br/web/campus-joinville/cursos)
  * [ estudantes](https://www.ifsc.edu.br/web/campus-joinville/estudantes)
  * [ comunidade](https://www.ifsc.edu.br/web/campus-joinville/comunidade)
  * [ comunicação](https://www.ifsc.edu.br/web/campus-joinville/comunicacao)


  * [Internacional](https://www.ifsc.edu.br/web/campus-joinville/international)
  * [Libras](https://www.ifsc.edu.br/web/campus-joinville/libras)


## Barra de busca
Barra de busca 
## Banner Home de Cursos
# Quer estudar no IFSC?
Deixe seu e-mail que avisaremos quando estivermos com inscrições abertas. 
[FAÇA SEU CADASTRO](https://www.ifsc.edu.br/web/campus-joinville/queroestudar)
## Home Cursos - linha 1
## Tipos de Cursos
#### Técnicos Integrados
Para quem deseja cursar as disciplinas do ensino médio e aprender uma profissão ao mesmo tempo.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/tecnicos-integrados)
#### Técnicos Concomitantes
Para quem faz o ensino médio em outra escola e quer estudar em um curso técnico do IFSC.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/tecnicos-concomitantes)
#### Técnicos Subsequentes
Para quem já terminou o ensino médio e quer uma rápida inserção no mercado de trabalho.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/tecnicos-subsequentes)
#### Qualificação Profissional e Idiomas
Cursos de curta duração, para quem quer se aperfeiçoar ou ingressar em nova área profissional.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/qualificacao-profissional)
## Home Cursos - linha 2
#### Graduação
Cursos de Ensino Superior para quem já concluiu o Ensino Médio. Podem durar de dois a quatro anos.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/graduacao)
#### Especialização
Cursos de especialização presenciais e a distância, com alto nível de excelência, pra quem já tem nível superior.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/especializacao)
#### EaD
Opções de cursos totalmente a distância e outros com parte das atividades de forma presencial.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/ead)
#### Todos os cursos
Conheça a lista completa de cursos do Câmpus Joinville.
[Saiba mais](https://www.ifsc.edu.br/web/campus-joinville/todos-os-cursos)
Oculto
## Rodapé Joinville
[](https://www.ifsc.edu.br/web/campus-joinville)
###### Social
  * [Facebook](https://www.facebook.com/ifsantacatarina/)
  * [Instagram](https://www.instagram.com/ifsc/)
  * [LinkedIn](https://www.linkedin.com/edu/ifsc---instituto-federal-de-santa-catarina-193019)
  * [YouTube](https://www.youtube.com/user/ifsccomunicacao)


###### O Câmpus
  * [Histórico](https://www.ifsc.edu.br/web/campus-joinville/historico)
  * [Estrutura Organizacional](https://www.ifsc.edu.br/web/campus-joinville/estrutura-organizacional)
  * [Colegiados](https://www.ifsc.edu.br/web/campus-joinville/colegiados)
  * [Documentos Norteadores](https://www.ifsc.edu.br/web/campus-joinville/documentos-norteadores)
  * [Eleições](https://www.ifsc.edu.br/web/campus-joinville/eleicoes)
  * [Trabalhe no IFSC](https://www.ifsc.edu.br/web/campus-joinville/trabalhe-no-ifsc)
  * [Licitações](https://www.ifsc.edu.br/web/campus-joinville/licitacoes)
  * [Acesso à Informação](https://www.ifsc.edu.br/web/campus-joinville/acesso-a-informacao)
  * [Ouvidoria](https://www.ifsc.edu.br/web/campus-joinville/ouvidoria)
  * [Editais](https://www.ifsc.edu.br/web/campus-joinville/editais_campus)


###### Cursos
  * [Técnicos Integrados](https://www.ifsc.edu.br/web/campus-joinville/tecnicos-integrados)
  * [Técnicos Concomitantes](https://www.ifsc.edu.br/web/campus-joinville/tecnicos-concomitantes)
  * [Técnicos Subsequentes](https://www.ifsc.edu.br/web/campus-joinville/tecnicos-subsequentes)
  * [Qualificação Profissional e Idiomas](https://www.ifsc.edu.br/web/campus-joinville/qualificacao-profissional)
  * [Graduação](https://www.ifsc.edu.br/web/campus-joinville/graduacao)
  * [Especialização](https://www.ifsc.edu.br/web/campus-joinville/especializacao)
  * [Educação a Distância](https://www.ifsc.edu.br/web/campus-joinville/ead)
  * [Todos os cursos](https://www.ifsc.edu.br/web/campus-joinville/todos-os-cursos)
  * [Resultados](https://www.ifsc.edu.br/web/campus-joinville/resultados)
  * [Resultados Vagas Remanescentes](https://www.ifsc.edu.br/web/campus-joinville/resultados-vagas-remanescentes)
  * [Transferências e Retornos](https://www.ifsc.edu.br/web/campus-joinville/transferencias-e-retornos)
  * [Inscrições e acompanhamento](https://www.ifsc.edu.br/web/campus-joinville/inscricoes-e-acompanhamento)
  * [Como posso estudar no IFSC?](https://www.ifsc.edu.br/web/campus-joinville/como-posso-estudar-no-ifsc-)
  * [Vagas em Regime Especial](https://www.ifsc.edu.br/web/campus-joinville/vagas-em-regime-especial)
  * [Calendários de inscrições](https://www.ifsc.edu.br/web/campus-joinville/calendario-de-inscricoes)
  * [Editais](https://www.ifsc.edu.br/web/campus-joinville/editais)
  * [Orientações para Matrícula](https://www.ifsc.edu.br/web/campus-joinville/orientacoes-para-matricula)
  * [Cotas](https://www.ifsc.edu.br/web/campus-joinville/cotas)
  * [Provas e Gabaritos](https://www.ifsc.edu.br/web/campus-joinville/provas-e-gabaritos)
  * [Estatísticas dos Processos Seletivos](https://www.ifsc.edu.br/web/campus-joinville/estatisticas-dos-processos-seletivos)
  * [Cadastro de interesse](https://www.ifsc.edu.br/web/campus-joinville/queroestudar)


###### Estudantes
  * [Estágio](https://www.ifsc.edu.br/web/campus-joinville/estagio)
  * [Calendário Acadêmico](https://www.ifsc.edu.br/web/campus-joinville/calendario-academico)
  * [Secretaria Acadêmica](https://www.ifsc.edu.br/web/campus-joinville/secretaria-academica)
  * [Formatura](https://www.ifsc.edu.br/web/campus-joinville/formatura)
  * [Horário de Aula](https://www.ifsc.edu.br/web/campus-joinville/horario-de-aula)
  * [Horário dos Professores](https://www.ifsc.edu.br/web/campus-joinville/horarios-dos-professores)
  * [Validação de Componentes Curriculares](https://www.ifsc.edu.br/web/campus-joinville/validacao-de-componentes-curriculares)
  * [Oportunidades](https://www.ifsc.edu.br/web/campus-joinville/oportunidades)
  * [Assistência Estudantil](https://www.ifsc.edu.br/web/campus-joinville/assistencia-estudantil)
  * [Documentos Úteis](https://www.ifsc.edu.br/web/campus-joinville/documentos-uteis)
  * [Bibliotecas](https://www.ifsc.edu.br/web/campus-joinville/bibliotecas)
  * [Sistemas Acadêmicos](https://www.ifsc.edu.br/web/campus-joinville/sistemas-academicos)
  * [Intercâmbio Estudantil](https://www.ifsc.edu.br/web/campus-joinville/intercambio-estudantil)
  * [Monitoria](https://www.ifsc.edu.br/web/campus-joinville/monitoria)
  * [Ações Inclusivas](https://www.ifsc.edu.br/web/campus-joinville/acoes-inclusivas)


###### Comunidade
  * [Certificações](https://www.ifsc.edu.br/web/campus-joinville/certificacoes)
  * [Pesquisa e Inovação](https://www.ifsc.edu.br/web/campus-joinville/pesquisa-e-inovacao)
  * [Extensão](https://www.ifsc.edu.br/web/campus-joinville/extensao)
  * [Chamadas Públicas](https://www.ifsc.edu.br/web/campus-joinville/chamadas-publicas-do-campus)
  * [Visitas Guiadas](https://www.ifsc.edu.br/web/campus-joinville/visitas-guiadas)


###### Comunicação
  * [Fale Conosco](https://www.ifsc.edu.br/web/campus-joinville/fale-conosco)
  * [Perguntas frequentes](https://www.ifsc.edu.br/web/campus-joinville/perguntas-frequentes1)
  * [Calendário de Eventos](https://www.ifsc.edu.br/web/campus-joinville/calendario-de-eventos)
  * [Notícias](https://www.ifsc.edu.br/web/campus-joinville/noticias)
  * [Assessoria de Imprensa](https://www.ifsc.edu.br/web/campus-joinville/assessoria-de-imprensa)
  * [Livros e Periódicos](https://www.ifsc.edu.br/web/campus-joinville/livros-e-periodicos)
  * [Identidade Visual do IFSC](https://www.ifsc.edu.br/web/campus-joinville/identidade-visual)


###### Câmpus Joinville
###### Instituto Federal de Educação, Ciência e Tecnologia de Santa Catarina - IFSC
Rua Pavão, 1377 - Costa e Silva - CEP 89220-618 Fone: (47) 3431-5600 
[![Acesso à informação](https://www.ifsc.edu.br/documents/20194/149549/acesso_informacao_rodape.png/b00559d4-76e8-9943-4f7e-0a3ac10c094d?t=1502300612000)](https://www.ifsc.edu.br/web/campus-joinville/acesso-a-informacao)
Copyright © 2022 Instituto Federal de Santa Catarina IFSC Todos os Direitos Reservados. 
Este site usa cookies para garantir que você obtenha a melhor experiência. [Leia Mais.](https://www.ifsc.edu.br/politica-de-cookies)
Aceitar
Recusar
[](https://www.ifsc.edu.br/web/campus-joinville/cursos)[](https://www.ifsc.edu.br/web/campus-joinville/cursos)


---

